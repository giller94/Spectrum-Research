import numpy as np 
from matplotlib import pyplot as plt
import os
from scipy.optimize import curve_fit
from Chips import*

##Inort data from sepctrum taken at Victoria Park 
txt = 'VickyP_spectrum.txt'

with open(txt, 'r') as f:
    
    size_to_read = 10
    f.seek(595)
    f_contents1 = f.readlines()
   
    
    
data = open("data500.txt", "w")
for element in f_contents1:
    data.write(element + "\n")
data.close()



with open("data500.txt", 'r') as ff:
    size_to_read = 8084
    f_contents2 = ff.read(size_to_read)
    #print(f_contents2)
    
data2 = open("data500.txt", "w")
for element in f_contents2:
    data2.write(element)
data2.close()

x = f_contents2.split("{")

y1 = []
y2 = []

for i in range(len(x)):
    y3 = x[i].partition(":")
    y1.append(y3[0].strip('""'))
    y2.append(y3[2].strip("},"))
    





y1 = y1[slice(400)]
y2 = y2[slice(400)]
#print(y1)
#target_ibdex
yy = np.array(y1)
yy2 = np.array(y2)

yy = np.delete(yy,0)
yy2 = np.delete(yy2, 0)
yy = np.delete(yy,0)
yy2 = np.delete(yy2, 0)




xfile = yy.astype(float)
yfile = yy2.astype(float)  



# =============================================================================
plt.plot(x405,y405,linewidth=3.0, color = 'darkviolet', label = '405nm')
plt.plot(x451,y451,linewidth=3.0,color = 'indigo', label = '451nm')
plt.plot(x475,y475,linewidth=3.0, color = 'blue', label = '475nm')
plt.plot(x500,y500,linewidth=3.0,color = 'Cyan', label = '500nm')
plt.plot(x526,y526,linewidth=3.0,color = 'Green', label = '526nm')
plt.plot(x548,y548,linewidth=3.0, color = 'Lime',label = '548nm')
plt.plot(x597,y597,linewidth=3.0, color = 'gold',label = '597nm')
plt.plot(x620,y620,linewidth=3.0,color = 'Orange', label = '620nm')
plt.plot(x630,y630,linewidth=3.0, color = 'red' , label = '630nm')
plt.plot(x665,y665,linewidth=3.0, color = 'firebrick', label = '665nm')
plt.plot(xfile,yfile,linewidth=6.0, color = 'black', label = 'Victoria Park Spectrum')
plt.xlabel('Wavelenght(nm)')
plt.ylabel('Relative Intensity')
plt.grid()
plt.legend()
